from setuptools import setup, find_packages

setup(
    name='preentrega2_baserga',
    version="0.1",
    packages=find_packages(),
    url='',
    license="",
    author='<MCBASERGA>',
    author_email="<mcbaserga@gmail.com>",
    description=''
)